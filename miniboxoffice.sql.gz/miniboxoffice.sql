-- phpMyAdmin SQL Dump
-- version 5.2.0-1.fc36.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 07, 2022 at 06:35 PM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miniboxoffice`
--

-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE `awards` (
  `id` int(11) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `isShort` tinyint(1) NOT NULL DEFAULT 0,
  `isFeature` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `awards`
--

INSERT INTO `awards` (`id`, `category_id`, `name`, `isShort`, `isFeature`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'Best Feature Film', 0, 1, '2022-08-16 02:02:08', '2022-08-27 17:08:23', NULL),
(2, 1, 'Best Short Film', 1, 0, '2022-08-16 02:15:24', '2022-08-16 02:15:24', NULL),
(3, 1, 'Best Animation', 1, 1, '2022-08-16 02:15:33', '2022-08-16 02:15:33', NULL),
(4, 1, 'Best Feature Animation', 0, 1, '2022-08-16 02:15:42', '2022-08-16 02:15:42', NULL),
(5, 1, 'Best Feature Documentary', 0, 1, '2022-08-16 02:15:52', '2022-08-16 02:15:52', NULL),
(6, 1, 'Short Documentary', 1, 0, '2022-08-16 02:16:01', '2022-08-16 02:16:01', NULL),
(7, 1, 'Best Music Video', 1, 1, '2022-08-16 02:16:12', '2022-08-16 02:16:12', NULL),
(8, 1, 'Best Film-Jury', 1, 1, '2022-08-16 02:16:20', '2022-08-16 02:16:20', NULL),
(9, 1, 'Best Director', 1, 1, '2022-08-16 02:16:29', '2022-08-16 02:16:29', NULL),
(10, 1, 'Best Debut Director', 0, 1, '2022-08-16 02:16:38', '2022-08-28 21:27:29', NULL),
(11, 1, 'Special Festival Mention', 1, 1, '2022-08-16 02:16:47', '2022-08-16 02:16:47', NULL),
(12, 1, 'Honorable Jury Mention', 1, 1, '2022-08-16 02:16:57', '2022-08-16 02:16:57', NULL),
(13, 1, 'Best Ad Film', 1, 0, '2022-08-16 02:17:07', '2022-08-16 02:17:07', NULL),
(14, 2, 'Best Cinematography', 1, 1, '2022-08-16 02:17:22', '2022-08-16 02:17:22', NULL),
(15, 2, 'Best Editing', 1, 1, '2022-08-16 02:17:37', '2022-08-16 02:17:37', NULL),
(16, 2, 'Best Screenplay', 1, 1, '2022-08-16 02:17:48', '2022-08-16 02:17:48', NULL),
(17, 2, 'Best VFX', 1, 1, '2022-08-16 02:17:59', '2022-08-16 02:17:59', NULL),
(18, 3, 'Best Actor', 1, 1, '2022-08-16 02:18:14', '2022-08-16 02:18:14', NULL),
(19, 3, 'Best Actress', 1, 1, '2022-08-16 02:18:28', '2022-08-27 22:39:10', NULL),
(20, 3, 'Best Supporting Actor', 1, 1, '2022-08-16 02:18:39', '2022-08-27 22:39:01', NULL),
(21, 3, 'Best Supporting Actress', 1, 1, '2022-08-16 02:18:50', '2022-08-27 22:38:54', NULL),
(22, 4, 'Best Original Music', 1, 1, '2022-08-16 02:19:04', '2022-08-27 22:38:45', NULL),
(23, 4, 'Best Background Music', 1, 1, '2022-08-16 02:19:15', '2022-08-27 22:38:38', NULL),
(101, 1, '0 test award', 1, 1, '2022-08-27 16:51:50', '2022-08-27 17:39:12', '2022-08-27 17:39:12'),
(102, 1, 'texting texing', 0, 1, '2022-08-27 17:12:10', '2022-08-27 17:39:01', '2022-08-27 17:39:01'),
(103, 1, 'test test', 1, 0, '2022-08-27 17:12:39', '2022-08-27 17:39:17', '2022-08-27 17:39:17'),
(104, 1, 'test 123', 1, 1, '2022-08-27 17:20:27', '2022-08-27 17:29:40', '2022-08-27 17:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `award_categories`
--

CREATE TABLE `award_categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `short_name` varchar(2) DEFAULT NULL,
  `short_student_inr` int(11) NOT NULL DEFAULT 0,
  `short_student_eur` int(11) NOT NULL DEFAULT 0,
  `short_professional_inr` int(11) NOT NULL DEFAULT 0,
  `short_professional_eur` int(11) NOT NULL DEFAULT 0,
  `feature_student_inr` int(11) NOT NULL DEFAULT 0,
  `feature_student_eur` int(11) NOT NULL DEFAULT 0,
  `feature_professional_inr` int(11) NOT NULL DEFAULT 0,
  `feature_professional_eur` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `award_categories`
--

INSERT INTO `award_categories` (`id`, `image`, `name`, `short_name`, `short_student_inr`, `short_student_eur`, `short_professional_inr`, `short_professional_eur`, `feature_student_inr`, `feature_student_eur`, `feature_professional_inr`, `feature_professional_eur`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '/public/uploads/awards_cat/1661627880_b55c61eba8d432601a72.png', 'Production', 'PR', 2000, 20, 3500, 35, 3500, 35, 5000, 50, '2022-08-16 11:06:02', '2022-08-27 14:21:33', NULL),
(2, '/public/uploads/awards_cat/1661628822_e7546da4042bb0fee948.png', 'Creative', 'CR', 2000, 20, 3500, 35, 3500, 35, 5000, 50, '2022-08-16 11:06:02', '2022-08-27 14:33:42', NULL),
(3, '/public/uploads/awards_cat/1661628848_dcf04c36e40f885c2011.png', 'Performance', 'PF', 2000, 20, 3500, 35, 3500, 35, 5000, 50, '2022-08-16 11:06:02', '2022-08-27 14:34:08', NULL),
(4, '/public/uploads/awards_cat/1661628872_42f5067de9690ec76941.png', 'Music', 'MU', 2000, 20, 3500, 35, 3500, 35, 5000, 50, '2022-08-16 11:06:02', '2022-08-27 14:34:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dynamicpagesdatas`
--

CREATE TABLE `dynamicpagesdatas` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `team_title` varchar(255) DEFAULT NULL,
  `team_content` text DEFAULT NULL,
  `volunteer_title` varchar(255) DEFAULT NULL,
  `volunteer_content` text DEFAULT NULL,
  `schedule_title` varchar(255) DEFAULT NULL,
  `schedule_content` text DEFAULT NULL,
  `delegate_title` varchar(255) DEFAULT NULL,
  `delegate_content` text DEFAULT NULL,
  `support_title` varchar(255) DEFAULT NULL,
  `support_content` text DEFAULT NULL,
  `winners_title` varchar(255) DEFAULT NULL,
  `winners_content` text DEFAULT NULL,
  `entry_form_title` varchar(255) DEFAULT NULL,
  `entry_form_content` text DEFAULT NULL,
  `official_selection_title` varchar(255) DEFAULT NULL,
  `official_selection_content` text DEFAULT NULL,
  `jury_title` varchar(255) DEFAULT NULL,
  `jury_content` text DEFAULT NULL,
  `gallery_title` varchar(255) DEFAULT NULL,
  `gallery_content` text DEFAULT NULL,
  `filmmakers_title` varchar(255) DEFAULT NULL,
  `filmmakers_content` text DEFAULT NULL,
  `knowledge_center_title` varchar(255) DEFAULT NULL,
  `knowledge_center_content` text DEFAULT NULL,
  `press_title` varchar(255) DEFAULT NULL,
  `press_content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dynamicpagesdatas`
--

INSERT INTO `dynamicpagesdatas` (`id`, `festival_id`, `team_title`, `team_content`, `volunteer_title`, `volunteer_content`, `schedule_title`, `schedule_content`, `delegate_title`, `delegate_content`, `support_title`, `support_content`, `winners_title`, `winners_content`, `entry_form_title`, `entry_form_content`, `official_selection_title`, `official_selection_content`, `jury_title`, `jury_content`, `gallery_title`, `gallery_content`, `filmmakers_title`, `filmmakers_content`, `knowledge_center_title`, `knowledge_center_content`, `press_title`, `press_content`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-23 07:04:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` enum('global','festival','filmmarket') DEFAULT NULL,
  `module_id` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `video_type` enum('youtube','vimeo') DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `from_time` time DEFAULT NULL,
  `to_time` time DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `pincode` int(7) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `google_map` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `type`, `module_id`, `image`, `video_type`, `video`, `title`, `content`, `category`, `from_date`, `to_date`, `from_time`, `to_time`, `address`, `country`, `state`, `city`, `pincode`, `latitude`, `longitude`, `google_map`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'festival', 4, '/uploads/event/2022/September/1662105607_596eace2c11ba48c2156.png', 'vimeo', '462692105', 'some test heading for discussion', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-09-14', '2022-09-30', '07:30:00', '11:30:00', '143/3rd Floor, Street Number 12, Zakir Nagar, Okhla, New Delhi, Delhi 110025', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:00:07', '2022-09-05 02:51:23', NULL),
(4, 'festival', 4, '/uploads/event/2022/September/1662468419_a805f71a381d4886d007.jpeg', 'youtube', '7vNQZEMgo4w', 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-08-12', '2022-09-29', '15:00:00', '21:00:00', 'H No-143, 4th floor, Gali No-13,, Flat No-3, Jamia Nagar, Okhla', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:11:49', '2022-09-06 07:46:59', NULL),
(5, 'festival', 4, '/uploads/event/2022/September/1662468419_a805f71a381d4886d007.jpeg', 'youtube', '7vNQZEMgo4w', 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-08-12', '2022-09-29', '15:00:00', '21:00:00', 'H No-143, 4th floor, Gali No-13,, Flat No-3, Jamia Nagar, Okhla', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:11:49', '2022-09-06 07:46:59', NULL),
(6, 'global', 4, '/uploads/event/2022/September/1662468419_a805f71a381d4886d007.jpeg', 'youtube', '7vNQZEMgo4w', 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-08-12', '2022-09-29', '15:00:00', '21:00:00', 'H No-143, 4th floor, Gali No-13,, Flat No-3, Jamia Nagar, Okhla', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:11:49', '2022-09-06 07:46:59', NULL),
(7, 'global', 4, '/uploads/event/2022/September/1662468419_a805f71a381d4886d007.jpeg', 'youtube', '7vNQZEMgo4w', 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-08-12', '2022-09-29', '15:00:00', '21:00:00', 'H No-143, 4th floor, Gali No-13,, Flat No-3, Jamia Nagar, Okhla', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:11:49', '2022-09-06 07:46:59', NULL),
(8, 'global', 4, '/uploads/event/2022/September/1662105607_596eace2c11ba48c2156.png', 'vimeo', '462692105', 'some test heading for discussion', '&lt;p&gt;In 2010, the poet, musician and my dear friend, Tanya Davis, wrote the beautiful poem, How to Be Alone, and from this we collaborated to make the film which you can see here vimeo.com/3850863 Ten years later, Tanya has written the gorgeous and poignant poem for these times, How to Be at Home, and we found ourselves collaborating again! This animation was created in my home studio in Halifax, Nova Scotia, while in social isolation through the spring and summer of 2020. How to Be at Home is one of thirty films created through, The Curve, a National Film Board of Canada series of films created within and about our pandemical times. You can see more of these wonderful and affecting films if you visit this link nfb.ca/the-curve/lights-camera-pivot/ Credits A National Film Board of Canada Production Poem written by Tanya Davis Directed, animated and edited by Andrea Dorfman Produced by Annette Clarke Original music by Tanya Davis and Daniel Ledwell Sound designed by Sacha Ratcliffe&lt;/p&gt;', 2, '2022-09-14', '2022-09-30', '07:30:00', '11:30:00', '143/3rd Floor, Street Number 12, Zakir Nagar, Okhla, New Delhi, Delhi 110025', 101, 4021, 131679, 110025, '28.567505', '77.280224', 'https://www.google.com/maps/dir//A+J+INFOTEK+143%2F3rd+Floor+Street+Number+12,+Zakir+Nagar,+Okhla+New+Delhi,+Delhi+110025/@28.567505,77.280224,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390ce38eb655e453:0x4ae1', '2022-09-02 03:00:07', '2022-09-05 02:51:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events_categories`
--

CREATE TABLE `events_categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events_categories`
--

INSERT INTO `events_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Sports', NULL, '2022-09-02 13:04:36', '2022-09-02 00:00:00', NULL),
(2, 'Music', NULL, '2022-09-02 00:10:59', '2022-09-02 00:15:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events_contacts`
--

CREATE TABLE `events_contacts` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` enum('global','event') NOT NULL DEFAULT 'global',
  `event_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events_contacts`
--

INSERT INTO `events_contacts` (`id`, `type`, `event_id`, `name`, `email`, `phone`, `whatsapp`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'global', 0, 'Mohammad Ahtesham', 'ahtesham2000@gmail.com', '+919873350509', '9810763314', '2022-09-05 01:27:04', '2022-09-05 01:27:04', NULL),
(2, 'global', 0, 'Gdgdgd dfjb jk', 'ahtesham2000@mailinator.com', '+919873350509', '9810763314', '2022-09-05 01:29:44', '2022-09-05 01:29:44', NULL),
(3, 'event', 4, 'Mohammad Ahtesham', 'ahtesham2000@gmail.com', '+919873350509', '9810763314', '2022-09-05 01:41:17', '2022-09-05 01:41:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events_contact_submitions`
--

CREATE TABLE `events_contact_submitions` (
  `id` int(11) UNSIGNED NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `events_tickets`
--

CREATE TABLE `events_tickets` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` enum('global','event') NOT NULL DEFAULT 'global',
  `event_id` int(11) NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `inr` float DEFAULT NULL,
  `eur` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events_tickets`
--

INSERT INTO `events_tickets` (`id`, `type`, `event_id`, `details`, `inr`, `eur`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'global', 0, '222 jhv dkjdvjk db jhdfvj dfvj ,hdb vj,dbvj ,dfvj ,dfb ,dfvb ,jdvbjdfvbjdvb dfhvj, d gv gv km', 2000, 20, '2022-09-04 08:00:40', '2022-09-04 08:05:50', NULL),
(2, 'event', 4, 'XRT - nbv hgc ghc jn', 5000, 50, '2022-09-05 00:07:55', '2022-09-05 00:24:29', NULL),
(3, 'event', 4, '222 jhv dkjdvjk db jhdfvj dfvj ,hdb vj,dbvj ,dfvj ,dfb ,dfvb ,jdvbjdfvbjdvb dfhvj, d gv gv km', 2000, 20, '2022-09-05 00:22:39', '2022-09-05 00:23:59', '2022-09-05 00:23:59'),
(4, 'event', 4, '222 jhv dkjdvjk db jhdfvj dfvj ,hdb vj,dbvj ,dfvj ,dfb ,dfvb ,jdvbjdfvbjdvb dfhvj, d gv gv km', 2000, 20, '2022-09-05 00:23:40', '2022-09-05 00:23:50', '2022-09-05 00:23:50'),
(5, 'event', 4, '222 jhv dkjdvjk db jhdfvj dfvj ,hdb vj,dbvj ,dfvj ,dfb ,dfvb ,jdvbjdfvbjdvb dfhvj, d gv gv km', 2000, 20, '2022-09-05 00:24:08', '2022-09-05 00:24:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festivals`
--

CREATE TABLE `festivals` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `rules` text DEFAULT NULL,
  `info_stats` text DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `current_year` int(4) DEFAULT NULL,
  `edition` int(11) DEFAULT 1,
  `opening_date` date DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `short_awards` tinyint(1) NOT NULL DEFAULT 0,
  `feature_awards` tinyint(1) NOT NULL DEFAULT 0,
  `project_types` text NOT NULL DEFAULT '[]',
  `award_category_to_show` text NOT NULL DEFAULT '[]',
  `awards_to_show` text NOT NULL DEFAULT '[]',
  `awards_prices` enum('custom','global') NOT NULL DEFAULT 'global',
  `short_awards_prices` text NOT NULL DEFAULT '[]',
  `feature_awards_prices` text NOT NULL DEFAULT '[]',
  `status` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festivals`
--

INSERT INTO `festivals` (`id`, `name`, `title`, `logo`, `rules`, `info_stats`, `slug`, `current_year`, `edition`, `opening_date`, `event_date`, `short_awards`, `feature_awards`, `project_types`, `award_category_to_show`, `awards_to_show`, `awards_prices`, `short_awards_prices`, `feature_awards_prices`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'Indian Cine Film Festival', '2nd Indian Cine Film Festival 2020', '/public/uploads/logos/yearly/4/1661160052_1255c0650ca6804aa9e1.jpg', '<h4>Edited rules?</h4>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<h4>What is Lorem Ipsum?</h4>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', NULL, 'indian-cine-film-festival', 2020, 8, '2022-07-14', '2023-06-11', 1, 1, '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"11\",\"12\"]', '[\"1\",\"2\",\"3\",\"4\"]', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\"]', 'custom', '[{\"award_id\":\"1\",\"award_name\":\"Production\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661627880_b55c61eba8d432601a72.png\",\"prices\":{\"inr\":{\"student\":\"2000\",\"professional\":\"3500\"},\"eur\":{\"student\":\"25\",\"professional\":\"44\"}}},{\"award_id\":\"2\",\"award_name\":\"Creative\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628822_e7546da4042bb0fee948.png\",\"prices\":{\"inr\":{\"student\":\"2000\",\"professional\":\"3500\"},\"eur\":{\"student\":\"25\",\"professional\":\"44\"}}},{\"award_id\":\"3\",\"award_name\":\"Performance\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628848_dcf04c36e40f885c2011.png\",\"prices\":{\"inr\":{\"student\":\"2000\",\"professional\":\"3500\"},\"eur\":{\"student\":\"25\",\"professional\":\"44\"}}},{\"award_id\":\"4\",\"award_name\":\"Music\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628872_42f5067de9690ec76941.png\",\"prices\":{\"inr\":{\"student\":\"2000\",\"professional\":\"3500\"},\"eur\":{\"student\":\"25\",\"professional\":\"44\"}}}]', '[{\"award_id\":\"1\",\"award_name\":\"Production\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661627880_b55c61eba8d432601a72.png\",\"prices\":{\"inr\":{\"student\":\"3500\",\"professional\":\"5000\"},\"eur\":{\"student\":\"44\",\"professional\":\"63\"}}},{\"award_id\":\"2\",\"award_name\":\"Creative\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628822_e7546da4042bb0fee948.png\",\"prices\":{\"inr\":{\"student\":\"3500\",\"professional\":\"5000\"},\"eur\":{\"student\":\"44\",\"professional\":\"63\"}}},{\"award_id\":\"3\",\"award_name\":\"Performance\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628848_dcf04c36e40f885c2011.png\",\"prices\":{\"inr\":{\"student\":\"3500\",\"professional\":\"5000\"},\"eur\":{\"student\":\"44\",\"professional\":\"63\"}}},{\"award_id\":\"4\",\"award_name\":\"Music\",\"award_image\":\"\\/public\\/uploads\\/awards_cat\\/1661628872_42f5067de9690ec76941.png\",\"prices\":{\"inr\":{\"student\":\"3500\",\"professional\":\"5000\"},\"eur\":{\"student\":\"44\",\"professional\":\"63\"}}}]', 1, '2022-08-09 05:43:40', '2022-08-31 08:18:44', NULL),
(6, 'Banglore Shorts Film Festival', NULL, NULL, '<p>festival rules updating</p>', NULL, 'bangalore-shorts-film-festival', NULL, 1, '2022-08-16', '2022-08-31', 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-09 05:57:52', '2022-08-27 05:29:04', NULL),
(13, 'Delhi Shorts International Film Festival', NULL, NULL, NULL, NULL, 'delhi-shorts-international-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:34:56', '2022-08-10 02:34:56', NULL),
(14, 'Mumbai Shorts International Film Festival', NULL, NULL, NULL, NULL, 'mumbai-shorts-international-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:35:32', '2022-08-10 02:35:32', NULL),
(15, 'Noida International Film Festival', NULL, NULL, NULL, NULL, 'noida-international-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:35:57', '2022-08-10 02:35:57', NULL),
(16, 'Short Film Festival', NULL, NULL, NULL, NULL, 'short-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:36:18', '2022-08-10 02:36:18', NULL),
(17, 'Indian World Film Festival', NULL, NULL, NULL, NULL, 'indian-world-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:36:30', '2022-08-10 02:36:30', NULL),
(18, 'Children Film Festival', NULL, NULL, NULL, NULL, 'children-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:36:52', '2022-08-10 02:36:52', NULL),
(19, 'Kolkata Shorts International Film Festival', NULL, NULL, NULL, NULL, 'kolkata-shorts-international-film-festival', NULL, 1, NULL, NULL, 0, 0, '[]', '[]', '[]', 'global', '[]', '[]', 0, '2022-08-10 02:37:12', '2022-08-10 02:37:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_about`
--

CREATE TABLE `festival_about` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `icon1` varchar(100) DEFAULT NULL,
  `icon_title1` varchar(100) DEFAULT NULL,
  `icon_content1` varchar(100) DEFAULT NULL,
  `icon2` varchar(100) DEFAULT NULL,
  `icon_title2` varchar(100) DEFAULT NULL,
  `icon_content2` varchar(100) DEFAULT NULL,
  `icon3` varchar(100) DEFAULT NULL,
  `icon_title3` varchar(100) DEFAULT NULL,
  `icon_content3` varchar(100) DEFAULT NULL,
  `icon4` varchar(100) DEFAULT NULL,
  `icon_title4` varchar(100) DEFAULT NULL,
  `icon_content4` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_about`
--

INSERT INTO `festival_about` (`id`, `festival_id`, `title`, `content`, `icon1`, `icon_title1`, `icon_content1`, `icon2`, `icon_title2`, `icon_content2`, `icon3`, `icon_title3`, `icon_content3`, `icon4`, `icon_title4`, `icon_content4`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 4, 'Founded in 2007 by Hello everyone, I fine here', '<p>Hello everyone, I fine here. Hello everyone, I fine hereHello everyone, I fine herevvvHello everyone, I fine hereHello everyone, I fine herevvvHello everyone, I fine hereHello everyone, I fine <strong>hereHello</strong> everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine hereHello everyone, I fine here</p>', 'fas fa-crown', 'Established in', 'Hello everyone, I fine here', 'fas fa-grin-beam', 'box title 2 1', 'box subtitle 2 2', 'fas fa-grin-wink', 'box title 3 1', 'box subtitle 3 2', 'fas fa-grin-squint-tears', 'box title 4 1', 'box subtitle 4 2', '2022-08-19 18:28:35', '2022-08-19 20:17:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_awards`
--

CREATE TABLE `festival_awards` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_awards`
--

INSERT INTO `festival_awards` (`id`, `festival_id`, `image`, `title`, `content`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(2, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(3, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(4, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(6, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(7, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(8, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL),
(9, 4, '/public/uploads/festival/awards/4/1660963873_bbfa243a4a74a828b4de.webp', 'Juries12 title', '2 Lorem ipsum dolor sit amet laoreet consectetuer adipiscing elit. Aenean commodo ligula egeasdfasd', '2022-08-19 21:51:13', '2022-08-19 22:22:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_awards_page`
--

CREATE TABLE `festival_awards_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_awards_page`
--

INSERT INTO `festival_awards_page` (`id`, `festival_id`, `title`, `content`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Founded in 2007 by Cameron Boyd, President of Furlined, we are a global production company with offices in Los Angeles, New York and London.', '<p>Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Praesent mattis risus sed tristique tristique. Nullam in urna consectetur, gravida est ut, porta urna. Maecenas mollis purus nec justo porttitor, ut placerat odio commodo. Praesent sodales lacus diam, et tristique nulla ultrices vitae. Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Nullam in urna consectetur.123</p>', '2022-08-19 22:23:00', '2022-08-19 22:23:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_banners`
--

CREATE TABLE `festival_banners` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_banners`
--

INSERT INTO `festival_banners` (`id`, `festival_id`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, '/public/uploads/festival/banners/4/1662454680_5ad0fd00483ae35bf5f8.jpg', '2022-09-06 03:58:00', '2022-09-06 03:58:00', NULL),
(2, 4, '/public/uploads/festival/banners/4/1662454915_f8e53a97bce2df5c0c0d.jpg', '2022-09-06 04:01:55', '2022-09-06 04:01:55', NULL),
(3, 4, '/public/uploads/festival/banners/4/1662454928_b0c48e89faeb1526355f.jpg', '2022-09-06 04:02:08', '2022-09-06 04:02:08', NULL),
(4, 4, '/public/uploads/festival/banners/4/1662455934_9b3cbc9a76c1f1a3a3f1.jpg', '2022-09-06 04:18:54', '2022-09-06 04:18:54', NULL),
(6, 4, '/public/uploads/festival/banners/4/1662456056_175e9ef6eeb0a0201bf0.jpg', '2022-09-06 04:20:56', '2022-09-06 04:20:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_deadlines`
--

CREATE TABLE `festival_deadlines` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `student_eur` int(11) DEFAULT 0,
  `student_inr` int(11) DEFAULT 0,
  `professional_eur` int(11) DEFAULT 0,
  `professional_inr` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_deadlines`
--

INSERT INTO `festival_deadlines` (`id`, `festival_id`, `name`, `deadline`, `student_eur`, `student_inr`, `professional_eur`, `professional_inr`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 4, 'Early deadline', '2022-08-31', 15, 1000, 18, 1500, '2022-08-25 03:22:28', '2022-08-27 03:35:40', '2022-08-27 03:35:40'),
(7, 4, 'Next Deadline', '2022-08-27', 0, 0, 0, 0, '2022-08-25 04:08:49', '2022-08-25 04:15:37', '2022-08-25 04:15:37'),
(8, 4, 'Another Deadline', '2022-08-31', 0, 0, 0, 0, '2022-08-25 04:14:15', '2022-08-25 04:15:21', '2022-08-25 04:15:21'),
(9, 4, 'Another Deadline', '2022-08-31', 8, 1200, 10, 1500, '2022-08-25 04:15:35', '2022-08-27 01:55:53', '2022-08-27 01:55:53'),
(10, 4, 'Pre Early Deadline', '2022-07-18', 30, 30, 30, 30, '2022-08-27 03:41:02', '2022-08-29 02:27:05', NULL),
(11, 4, 'Another Deadline', '2022-08-31', 0, 0, 0, 0, '2022-08-27 04:44:31', '2022-08-27 04:53:46', '2022-08-27 04:53:46'),
(12, 4, 'Early deadline', '2022-08-28', 0, 0, 0, 0, '2022-08-27 04:50:39', '2022-08-27 04:53:50', '2022-08-27 04:53:50'),
(13, 4, 'Early deadline', '2022-09-15', 0, 0, 0, 0, '2022-08-27 04:54:07', '2022-08-29 01:57:34', '2022-08-29 01:57:34'),
(14, 4, 'text deadline', '2022-08-29', 0, 0, 0, 0, '2022-08-27 04:55:21', '2022-08-29 01:57:27', '2022-08-29 01:57:27'),
(15, 4, 'Another Deadline', '2022-08-25', 0, 0, 0, 0, '2022-08-27 04:58:16', '2022-08-29 01:57:30', '2022-08-29 01:57:30'),
(16, 4, 'Early Deadline', '2022-08-07', 28, 28, 28, 28, '2022-08-29 02:16:38', '2022-08-29 02:34:41', NULL),
(17, 4, 'Pre Deadline ', '2022-08-27', 26, 26, 26, 26, '2022-08-29 02:18:07', '2022-08-29 02:35:42', NULL),
(18, 4, 'Semi Deadline', '2022-09-16', 24, 24, 24, 24, '2022-08-29 02:18:24', '2022-08-29 02:35:35', NULL),
(19, 4, 'Quarter Deadline', '2022-10-06', 22, 22, 22, 22, '2022-08-29 02:18:42', '2022-08-29 02:35:28', NULL),
(20, 4, 'Pre- Regular', '2022-10-26', 20, 20, 20, 20, '2022-08-29 02:19:16', '2022-08-29 02:35:21', NULL),
(21, 4, 'Semi-Regular Deadline', '2022-11-15', 18, 18, 18, 18, '2022-08-29 02:19:30', '2022-08-29 02:35:15', NULL),
(22, 4, 'Quarter Regular Deadline', '2022-12-05', 16, 16, 16, 16, '2022-08-29 02:19:46', '2022-08-29 02:35:08', NULL),
(23, 4, 'Regular Deadline', '2022-12-25', 14, 14, 14, 14, '2022-08-29 02:20:11', '2022-08-29 02:35:02', NULL),
(24, 4, 'Late Deadline', '2023-06-02', 0, 0, 0, 0, '2022-08-29 02:20:30', '2022-08-29 02:20:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_delegates`
--

CREATE TABLE `festival_delegates` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `festival_year` int(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `movie_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `package_details` text DEFAULT NULL,
  `ticket_details` text DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `gateway_order_id` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `festival_delegate_packages`
--

CREATE TABLE `festival_delegate_packages` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `fee_inr` int(11) DEFAULT NULL,
  `fee_eur` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_delegate_packages`
--

INSERT INTO `festival_delegate_packages` (`id`, `festival_id`, `details`, `fee_inr`, `fee_eur`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Screening & networking with lunch & morning/evening tea coffee & snacks.', 800, 10, '2022-08-24 01:22:05', '2022-08-24 04:26:34', NULL),
(2, 4, 'Screening & Networking, Master Class on Film Funding [For emerging filmmakers], with lunch & morning/evening tea coffee.', 2000, 20, '2022-08-24 01:27:33', '2022-08-24 04:27:08', NULL),
(3, 4, 'Screening & Networking, Master Class on Marketing, promotion, distribution & Revenue generation through Short films with lunch & morning/evening tea coffee.', 3000, 30, '2022-08-24 01:28:00', '2022-08-24 04:48:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_galleries`
--

CREATE TABLE `festival_galleries` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_galleries`
--

INSERT INTO `festival_galleries` (`id`, `festival_id`, `image`, `caption`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, '/public/uploads/festival/gallery/4/1661400981_f79ae2e5e1c99b801ef3.png', 'some caption for the gallery image xrt', '2022-08-24 23:16:21', '2022-08-24 23:20:10', NULL),
(2, 4, '/public/uploads/festival/gallery/4/1661402514_2443b8d6fc3146ad8833.webp', '', '2022-08-24 23:41:54', '2022-08-24 23:41:54', NULL),
(3, 4, '/public/uploads/festival/gallery/4/1661402538_5007db4315786e7b85ed.jpg', '', '2022-08-24 23:42:18', '2022-08-24 23:42:18', NULL),
(5, 4, '/public/uploads/festival/gallery/4/1661402578_90990559afa102347f90.jpg', '', '2022-08-24 23:42:58', '2022-08-24 23:42:58', NULL),
(6, 4, '/public/uploads/festival/gallery/4/1661402595_7c24f9d6eab0bc1e083a.png', '', '2022-08-24 23:43:15', '2022-08-24 23:43:15', NULL),
(7, 4, '/public/uploads/festival/gallery/4/1661402642_0c6e75b7fb5a536e075d.webp', '', '2022-08-24 23:44:02', '2022-08-24 23:44:02', NULL),
(8, 4, '/public/uploads/festival/gallery/4/1661402658_93111af0827823f2cef9.webp', '', '2022-08-24 23:44:18', '2022-08-24 23:44:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_juries`
--

CREATE TABLE `festival_juries` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `festival_year` int(4) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `gallery` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_juries`
--

INSERT INTO `festival_juries` (`id`, `festival_id`, `festival_year`, `first_name`, `last_name`, `email`, `mobile`, `profession`, `about`, `image`, `facebook`, `twitter`, `instagram`, `whatsapp`, `title`, `content`, `video`, `gallery`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2020, 'Sonia', 'Williams', NULL, NULL, 'Director/Musician', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat. Nibh cras pulvinar mattis nunc sed blandit libero. Vitae congue mauris rhoncus aenean vel elit scelerisque mauris pellentesque.', '/public/uploads/festival/jury/image/4/1661237250_3c95513cd74817b2671a.webp', 'http://facebook.com', 'http://twitter.com', 'http://instagram.com', '9810763314', 'Create your own visual style. Let it be unique for yourself and yet identifiable to others.', 'Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Praesent mattis risus sed tristique tristique. Nullam in urna consectetur, gravida est ut, porta urna. Maecenas mollis purus nec justo porttitor, ut placerat odio commodo. Praesent sodales lacus diam, et tristique nulla ultrices vitae. Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Nullam in urna consectetur.', 'https://www.youtube.com/watch?v=neYXuKSz9k8', NULL, '2022-08-23 01:47:30', '2022-08-23 04:11:34', NULL),
(2, 4, 2019, 'Suzan', 'Melody', NULL, NULL, 'Director/Musician', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat. Nibh cras pulvinar mattis nunc sed blandit libero. Vitae congue mauris rhoncus aenean vel elit scelerisque mauris pellentesque.', '/public/uploads/festival/jury/image/4/1661249806_d2036c91ea9dfe009dd2.webp', NULL, NULL, NULL, NULL, 'Create your own visual style. Let it be unique for yourself and yet identifiable to others.', 'Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Praesent mattis risus sed tristique tristique. Nullam in urna consectetur, gravida est ut, porta urna. Maecenas mollis purus nec justo porttitor, ut placerat odio commodo. Praesent sodales lacus diam, et tristique nulla ultrices vitae. Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Nullam in urna consectetur.', 'https://www.youtube.com/watch?v=7vNQZEMgo4w', NULL, '2022-08-23 05:16:46', '2022-08-23 05:16:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_jury_galleries`
--

CREATE TABLE `festival_jury_galleries` (
  `id` int(11) UNSIGNED NOT NULL,
  `jury_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_jury_galleries`
--

INSERT INTO `festival_jury_galleries` (`id`, `jury_id`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(8, 1, '/public/uploads/festival/jury/gallery/4/1661248577_47a69dd46ec5ffb06b71.png', '2022-08-23 04:56:17', '2022-08-23 04:56:17', NULL),
(9, 1, '/public/uploads/festival/jury/gallery/4/1661248577_609181357011450dfd48.jpg', '2022-08-23 04:56:17', '2022-08-23 04:56:17', NULL),
(10, 1, '/public/uploads/festival/jury/gallery/4/1661248577_2119d1b3a45c63c9d587.png', '2022-08-23 04:56:17', '2022-08-23 04:56:17', NULL),
(11, 1, '/public/uploads/festival/jury/gallery/4/1661248577_ebdbb17d8a3b10639560.png', '2022-08-23 04:56:17', '2022-08-23 04:56:17', NULL),
(12, 1, '/public/uploads/festival/jury/gallery/4/1661248577_f7811e6a84e627eb2c3a.png', '2022-08-23 04:56:17', '2022-08-23 04:56:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_presses`
--

CREATE TABLE `festival_presses` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `festival_year` int(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_presses`
--

INSERT INTO `festival_presses` (`id`, `festival_id`, `festival_year`, `title`, `url`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 4, 2019, 'Lucifer', 'https://www.almspay.com/', '2022-08-24 06:55:52', '2022-08-24 06:56:31', NULL),
(3, 4, 2020, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', 'https://www.facebook.com/groups/416901795174581/permalink/1786737704857643/', '2022-08-24 06:56:04', '2022-08-24 06:56:04', NULL),
(4, 4, 2020, 'Create your own visual style. Let it be unique for yourself and yet identifiable to others.', 'http://frontend.hillstay.in/', '2022-08-24 06:56:21', '2022-08-24 06:56:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_schedules`
--

CREATE TABLE `festival_schedules` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `festival_year` int(4) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_schedules`
--

INSERT INTO `festival_schedules` (`id`, `festival_id`, `festival_year`, `title`, `content`, `image`, `pdf`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2010, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', '', '/public/uploads/festival/schedule/image/4/1661195470_68c1aacba61eaa6ce4c0.jpg', '/public/uploads/festival/schedule/pdf/4/1661195712_fe6c1ca48ccf851daa0e.pdf', '2022-08-22 14:11:10', '2022-08-22 14:15:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_sponsorship`
--

CREATE TABLE `festival_sponsorship` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `icon1` varchar(100) DEFAULT NULL,
  `icon_title1` varchar(100) DEFAULT NULL,
  `icon_content1` varchar(100) DEFAULT NULL,
  `icon2` varchar(100) DEFAULT NULL,
  `icon_title2` varchar(100) DEFAULT NULL,
  `icon_content2` varchar(100) DEFAULT NULL,
  `icon3` varchar(100) DEFAULT NULL,
  `icon_title3` varchar(100) DEFAULT NULL,
  `icon_content3` varchar(100) DEFAULT NULL,
  `icon4` varchar(100) DEFAULT NULL,
  `icon_title4` varchar(100) DEFAULT NULL,
  `icon_content4` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_sponsorship`
--

INSERT INTO `festival_sponsorship` (`id`, `festival_id`, `title`, `content`, `icon1`, `icon_title1`, `icon_content1`, `icon2`, `icon_title2`, `icon_content2`, `icon3`, `icon_title3`, `icon_content3`, `icon4`, `icon_title4`, `icon_content4`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Founded in 2007 by Cameron Boyd, President of Furlined, we are a global production company with', '<p style=\"text-align: center;\">Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Praesent mattis risus sed tristique tristique. Nullam in urna consectetur, gravida est ut, porta urna. Maecenas mollis purus nec justo porttitor, ut placerat odio commodo. Praesent sodales lacus diam, et tristique nulla ultrices vitae. Etiam vehicula, justo nec sollicitudin vehicula, diam ante ultrices orci, at tempor nisl nulla ac metus. Nulla porttitor mi sit amet quam tincidunt malesuada. Nullam in urna consectetur.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-08-19 20:20:23', '2022-08-19 20:28:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_teams`
--

CREATE TABLE `festival_teams` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_teams`
--

INSERT INTO `festival_teams` (`id`, `festival_id`, `first_name`, `last_name`, `profession`, `about`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Ahtesham', 'Chaudhary2', 'Director / Producer', 'Some content about team member', '/public/uploads/festival/team/image/4/1661233631_c9f503ef0a7d955a8172.jpg', '2022-08-23 00:47:11', '2022-08-23 01:06:19', '2022-08-23 01:06:19'),
(2, 4, 'Ahtesham', 'Chaudhary', 'Director / Producer', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat. Nibh cras pulvinar mattis nunc sed blandit libero. Vitae congue mauris rhoncus aenean vel elit scelerisque mauris pellentesque.', '/public/uploads/festival/team/image/4/1661234842_13c5b032af1d8695b70e.jpg', '2022-08-23 01:07:22', '2022-08-23 01:07:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_type_of_films`
--

CREATE TABLE `festival_type_of_films` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('Short','Feature') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Short',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `festival_type_of_films`
--

INSERT INTO `festival_type_of_films` (`id`, `name`, `type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Feature Film (61 min to 180 min) ', 'Feature', '2022-08-16 06:14:25', '2022-08-27 06:55:11', NULL),
(2, 'Feature Documentary (61 min to 180 min)', 'Feature', '2022-08-16 22:36:37', '2022-08-27 06:55:02', NULL),
(3, 'Short Film (1 m to 60 min)', 'Short', '2022-08-16 22:43:10', '2022-08-27 06:55:56', NULL),
(4, 'Short Documentary (1 m to 60 min)', 'Short', '2022-08-16 22:43:27', '2022-08-27 06:56:11', NULL),
(5, 'Feature Animation (61 min to 180 min)', 'Feature', '2022-08-16 22:43:41', '2022-08-27 06:55:41', NULL),
(6, 'Short Animation (1 m to 60 min)', 'Short', '2022-08-16 22:43:55', '2022-08-25 06:05:36', NULL),
(7, 'Short Music Video (up to 10 min)', 'Short', '2022-08-16 22:44:09', '2022-08-25 06:06:02', NULL),
(8, 'Short Ad Film (up to 4 min)', 'Short', '2022-08-16 22:44:22', '2022-08-25 06:06:25', NULL),
(9, 'Screenplay Short', 'Short', '2022-08-25 06:06:47', '2022-08-27 06:50:07', '2022-08-27 06:50:07'),
(10, 'Screenplay Feature', 'Short', '2022-08-25 06:07:10', '2022-08-27 06:49:56', '2022-08-27 06:49:56'),
(11, 'Screenplay Short', 'Short', '2022-08-27 06:56:59', '2022-08-27 06:56:59', NULL),
(12, 'Screenplay Feature', 'Feature', '2022-08-27 06:57:12', '2022-08-27 06:57:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_venues`
--

CREATE TABLE `festival_venues` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_venues`
--

INSERT INTO `festival_venues` (`id`, `festival_id`, `title`, `content`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Venue title', '<p>My Venue description</p>', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_venues_items`
--

CREATE TABLE `festival_venues_items` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `festival_year` int(4) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_venues_items`
--

INSERT INTO `festival_venues_items` (`id`, `festival_id`, `festival_year`, `title`, `content`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2022, 'Award WINNING MOVIES ONCE UPON A TIME', 'Video production work with producing video content. It is the analogical of film making, but the images are digitally recorded instead of film stock. There are three levels of video production: production, pre-production and', '/public/uploads/festival/venue/4/1661163534_2713fd562b96ed27a49f.png', NULL, NULL, NULL),
(2, 4, 2005, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', 'Flash Filmis an award winning creative production company working for various clients and agencies in both New York & LA', '/public/uploads/festival/venue/4/1661167243_a7045dc040a4d9b49f0e.webp', NULL, NULL, NULL),
(3, 4, 2010, 'Beyoncé - SPIRIT (From Disney\'s \"The Lion King\" - Official Video)', 'Her face has the flawless sheen of Photoshop-adjusted models in cosmetics ads – an uncanny smoothness that leads us to make our own inferences about her character', '/public/uploads/festival/venue/4/1661167287_72d8cd726ec441845f67.jpeg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_volunteers`
--

CREATE TABLE `festival_volunteers` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) DEFAULT NULL,
  `festival_year` int(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `festival_volunteers`
--

INSERT INTO `festival_volunteers` (`id`, `festival_id`, `festival_year`, `name`, `email`, `whatsapp`, `mobile`, `address`, `country`, `state`, `city`, `pin`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2020, 'Ahtesham Chaudhary', 'ahtesham2000@gmail.com', '9810763314', '05656565656', 'H No-143, 4th floor, Gali No-13,, Flat No-3, Jamia Nagar, Okhla', 101, 4021, 131679, 110025, '2022-08-23 07:18:17', '2022-08-23 07:18:17', NULL),
(3, 4, 2020, 'Gdgdgd dfjb jk', 'ahtesham2000@mailinator.com', '9810763314', '+919873350509', '143-st No.-13 ntr', 101, 4021, 131679, 112255, '2022-08-23 07:24:29', '2022-08-23 07:24:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `festival_winners`
--

CREATE TABLE `festival_winners` (
  `id` int(11) UNSIGNED NOT NULL,
  `festival_id` int(11) NOT NULL,
  `year` int(4) DEFAULT NULL,
  `selection_id` varchar(100) DEFAULT NULL,
  `sort` int(5) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `filmzine`
--

CREATE TABLE `filmzine` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `type_name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `media_url` varchar(255) DEFAULT NULL,
  `media_type` enum('image','video') NOT NULL DEFAULT 'image',
  `video_type` enum('youtube','vimeo') DEFAULT NULL,
  `topic_id` int(11) NOT NULL,
  `topic_name` varchar(255) DEFAULT NULL,
  `total_likes` int(11) NOT NULL,
  `total_dislikes` int(11) NOT NULL,
  `movie_rating` float DEFAULT NULL,
  `total_views` bigint(20) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filmzine`
--

INSERT INTO `filmzine` (`id`, `user_id`, `type_id`, `type_name`, `slug`, `featured`, `title`, `summary`, `content`, `media_url`, `media_type`, `video_type`, `topic_id`, `topic_name`, `total_likes`, `total_dislikes`, `movie_rating`, `total_views`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 3, 'Interviews', 'designed-and-built-with-all-the-love-in-the-world-by-the-bootstrap-team-with-the-help-of-our-contributors', 1, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\n&lt;/div&gt;\n&lt;div class=&quot;entry-content&quot;&gt;\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&amp;nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&amp;nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&amp;rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&amp;rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\n&lt;/div&gt;', '/uploads/filmzine/2022/August/1661927795_0abf5fdd73756bf02136.png', 'image', NULL, 1, 'General', 0, 0, 1.5, 0, 1, '2022-08-31 01:36:35', '2022-08-31 01:36:35', NULL),
(2, 1, 1, 'Article', 'deleted-vimeo-let-it-be-unique-for-yourself-and-yet-identifiable-to-others', 1, 'Deleted Vimeo. Let it be unique for yourself and yet identifiable to others.', 'Intrinsicly productivate corporate e-markets after performance based deliverables. Rapidiously engage low-risk high-yield data before high standards in mindshare. ', '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', '742504676', 'video', 'vimeo', 2, 'Entertainment', 0, 0, NULL, 0, 0, '2022-08-31 01:46:03', '2022-09-05 07:27:55', NULL),
(3, 1, 2, 'Movie Review', 'designed-and-built-with-all-the-love-in-the-world-by-the-bootstrap-team-with-the-help-of-our-contributors-2', 1, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&amp;nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&amp;nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&amp;rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&amp;rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', '/uploads/filmzine/2022/August/1661927795_0abf5fdd73756bf02136.png', 'image', NULL, 1, 'General', 0, 0, 1.5, 0, 1, '2022-08-31 01:36:35', '2022-08-31 01:36:35', NULL),
(4, 1, 4, 'Video Trailer', 'youtube-let-it-be-unique-for-yourself-and-yet-identifiable-to-others', 1, 'Youtube. Let it be unique for yourself and yet identifiable to others.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', 'wXuQx9NdTXg', 'video', 'youtube', 1, 'General', 0, 0, NULL, 0, 0, '2022-08-31 01:46:03', '2022-09-01 00:32:47', NULL),
(5, 1, 5, 'Knowledge Center', 'knowledge-series-2016-film-festivals-and-markets-building-audiences-and-business-opportunities', 1, 'Knowledge Series 2016 - Film Festivals and Markets – Building Audiences and Business Opportunities', 'A good festival run ensures not just accolades but also inroads into markets that might have been historically unexplored by the cultures that they originate from.', '&lt;p&gt;&lt;strong&gt;Panelists&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Raam Reddy, Filmmaker&lt;/li&gt;\r\n&lt;li&gt;Chris Paton, Sales Agent&lt;/li&gt;\r\n&lt;li&gt;Paolo Bertolin, Festival Programmer&lt;/li&gt;\r\n&lt;li&gt;Uma DaCunha, Film Festival Director, Filmmaker&lt;/li&gt;\r\n&lt;li&gt;Kanu Behl, Filmmaker&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Moderated by:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Deepti DCunha, Consultant, Curator&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;Film programmer Film Festivals showcase films from across the world to discerning audiences. A good festival run ensures not just accolades but also inroads into markets that might have been historically unexplored by the cultures that they originate from. Film Markets are like a major meet and greet arena where filmmakers and buyers/ aggregators converge from across the world to find synergies between the films and the possible cultures that might consume them. It&amp;rsquo;s all about expanding the scope of one&amp;rsquo;s own kind of cinema by identifying the kind of audiences that it resonates with and then work towards finding them and expanding that community and its understanding of the same. This session aims to delve into understanding international demographics for South Asian &amp;amp; Indian Content &amp;ndash; what works and on what platform, discussing the key Film Festivals &amp;amp; Markets across the world and what makes them special for South Asian Content, building a customized festival &amp;amp; market itineraries and exploring fresh exploitation avenues&lt;/p&gt;', 'F7-WXAfQnk8', 'video', 'youtube', 1, 'General', 0, 0, NULL, 0, 0, '2022-09-05 07:08:01', '2022-09-05 07:08:01', NULL),
(6, 1, 1, 'Article', 'knowledge-series-2016-film-festivals-and-markets-building-audiences-and-business-opportunities', 1, 'Knowledge Series 2016 - Film Festivals and Markets – Building Audiences and Business Opportunities', 'A good festival run ensures not just accolades but also inroads into markets that might have been historically unexplored by the cultures that they originate from.', '&lt;p&gt;&lt;strong&gt;Panelists&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Raam Reddy, Filmmaker&lt;/li&gt;\r\n&lt;li&gt;Chris Paton, Sales Agent&lt;/li&gt;\r\n&lt;li&gt;Paolo Bertolin, Festival Programmer&lt;/li&gt;\r\n&lt;li&gt;Uma DaCunha, Film Festival Director, Filmmaker&lt;/li&gt;\r\n&lt;li&gt;Kanu Behl, Filmmaker&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Moderated by:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Deepti DCunha, Consultant, Curator&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;Film programmer Film Festivals showcase films from across the world to discerning audiences. A good festival run ensures not just accolades but also inroads into markets that might have been historically unexplored by the cultures that they originate from. Film Markets are like a major meet and greet arena where filmmakers and buyers/ aggregators converge from across the world to find synergies between the films and the possible cultures that might consume them. It&amp;rsquo;s all about expanding the scope of one&amp;rsquo;s own kind of cinema by identifying the kind of audiences that it resonates with and then work towards finding them and expanding that community and its understanding of the same. This session aims to delve into understanding international demographics for South Asian &amp;amp; Indian Content &amp;ndash; what works and on what platform, discussing the key Film Festivals &amp;amp; Markets across the world and what makes them special for South Asian Content, building a customized festival &amp;amp; market itineraries and exploring fresh exploitation avenues&lt;/p&gt;', 'F7-WXAfQnk8', 'video', 'youtube', 1, 'General', 0, 0, NULL, 0, 0, '2022-09-05 07:08:01', '2022-09-05 07:08:01', NULL),
(7, 1, 3, 'Interviews', 'youtube-let-it-be-unique-for-yourself-and-yet-identifiable-to-others', 1, 'Youtube. Let it be unique for yourself and yet identifiable to others.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', 'wXuQx9NdTXg', 'video', 'youtube', 1, 'General', 0, 0, NULL, 0, 0, '2022-08-31 01:46:03', '2022-09-01 00:32:47', NULL),
(8, 1, 3, 'Interviews', 'designed-and-built-with-all-the-love-in-the-world-by-the-bootstrap-team-with-the-help-of-our-contributors-2', 1, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&amp;nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&amp;nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&amp;rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&amp;rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', '/uploads/filmzine/2022/August/1661927795_0abf5fdd73756bf02136.png', 'image', NULL, 1, 'General', 0, 0, 1.5, 0, 1, '2022-08-31 01:36:35', '2022-08-31 01:36:35', NULL),
(9, 1, 1, 'Article', 'vimeo-let-it-be-unique-for-yourself-and-yet-identifiable-to-others', 1, 'Vimeo. Let it be unique for yourself and yet identifiable to others.', 'Intrinsicly productivate corporate e-markets after performance based deliverables. Rapidiously engage low-risk high-yield data before high standards in mindshare. ', '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', '742504676', 'video', 'vimeo', 2, 'Entertainment', 0, 0, NULL, 0, 0, '2022-08-31 01:46:03', '2022-09-01 00:14:59', NULL),
(10, 1, 3, 'Interviews', 'designed-and-built-with-all-the-love-in-the-world-by-the-bootstrap-team-with-the-help-of-our-contributors', 1, 'Designed and built with all the love in the world by the Bootstrap team with the help of our contributors.', NULL, '&lt;div class=&quot;entry-headline h5&quot;&gt;\r\n&lt;p&gt;Monotonectally pursue backward-compatible ideas without empowered imperatives. Interactively predominate low-risk high-yield ROI rather than adaptive e-tailers. Progressively morph standardized value vis-a-vis just in time portals. Quickly repurpose ethical vortals rather than technically sound systems. Intrinsicly formulate.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;entry-content&quot;&gt;\r\n&lt;p&gt;Flexitarian swag chia food truck stumptown lomo, master cleanse deep v pickled actually. Organic gluten-free High Life, lo-fi squid butcher seitan. Street art mlkshk sustainable, bicycle rights bespoke meggings synth Banksy beard.&amp;nbsp;&lt;a href=&quot;http://sky360.in/mini_box_office/filmzine/details-page.html&quot;&gt;IPhone master cleanse&lt;/a&gt;&amp;nbsp;retro swag fingerstache fashion axe migas. Intelligentsia roof party Thundercats 90&amp;rsquo;s Vice, biodiesel disrupt hoodie +1 pickled cred butcher mixtape. Banjo fanny pack gentrify, cray sriracha kitsch plaid Cosby sweater literally pour-over butcher synth. Church-key meh aesthetic, you probably haven&amp;rsquo;t heard of them food truck VHS master cleanse freegan 3 wolf moon gluten-free mustache.&lt;/p&gt;\r\n&lt;/div&gt;', '/uploads/filmzine/2022/August/1661927795_0abf5fdd73756bf02136.png', 'image', NULL, 1, 'General', 0, 0, 1.5, 0, 1, '2022-08-31 01:36:35', '2022-08-31 01:36:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `filmzinetomodules`
--

CREATE TABLE `filmzinetomodules` (
  `id` int(11) UNSIGNED NOT NULL,
  `news_id` int(11) NOT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `data_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filmzinetomodules`
--

INSERT INTO `filmzinetomodules` (`id`, `news_id`, `table_name`, `data_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(6, 4, 'festival', 4, '2022-09-01 00:32:59', '2022-09-01 00:32:59', NULL),
(7, 1, 'festival', 4, '2022-09-05 03:00:11', '2022-09-05 03:00:11', NULL),
(8, 5, 'festival', 4, '2022-09-05 07:12:59', '2022-09-05 07:12:59', NULL),
(9, 6, 'festival', 4, '2022-09-05 07:16:59', '2022-09-05 07:16:59', NULL),
(10, 10, 'festival', 4, '2022-09-05 07:17:14', '2022-09-05 07:17:14', NULL),
(11, 7, 'festival', 4, '2022-09-05 07:17:26', '2022-09-05 07:17:26', NULL),
(12, 9, 'festival', 4, '2022-09-05 07:17:44', '2022-09-05 07:17:44', NULL),
(13, 8, 'festival', 4, '2022-09-05 07:17:59', '2022-09-05 07:17:59', NULL),
(38, 8, 'homepage', 4, '2022-09-05 07:17:59', '2022-09-05 07:17:59', NULL),
(39, 9, 'homepage', 4, '2022-09-05 07:17:44', '2022-09-05 07:17:44', NULL),
(40, 7, 'homepage', 4, '2022-09-05 07:17:26', '2022-09-05 07:17:26', NULL),
(41, 10, 'homepage', 4, '2022-09-05 07:17:14', '2022-09-05 07:17:14', NULL),
(42, 6, 'homepage', 4, '2022-09-05 07:16:59', '2022-09-05 07:16:59', NULL),
(44, 1, 'homepage', 4, '2022-09-05 03:00:11', '2022-09-05 03:00:11', NULL),
(45, 4, 'homepage', 4, '2022-09-01 00:32:59', '2022-09-01 00:32:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `filmzine_likes`
--

CREATE TABLE `filmzine_likes` (
  `id` int(11) UNSIGNED NOT NULL,
  `news_id` int(11) NOT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `liked` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `filmzine_topics`
--

CREATE TABLE `filmzine_topics` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filmzine_topics`
--

INSERT INTO `filmzine_topics` (`id`, `name`, `image`, `color`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'General', NULL, '#808080', '2022-08-30 19:02:38', '2022-08-30 19:02:38', NULL),
(2, 'Entertainment', NULL, '#800000', '2022-08-30 19:02:38', '2022-08-30 19:02:38', NULL),
(3, 'test topic', NULL, '#000000', '2022-08-31 06:01:58', '2022-08-31 06:07:20', '2022-08-31 06:07:20');

-- --------------------------------------------------------

--
-- Table structure for table `filmzine_types`
--

CREATE TABLE `filmzine_types` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rating` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filmzine_types`
--

INSERT INTO `filmzine_types` (`id`, `name`, `rating`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Article', 0, '2022-08-30 19:00:37', '2022-08-30 19:00:37', NULL),
(2, 'Movie Review', 1, '2022-08-30 19:00:37', '2022-08-30 19:00:37', NULL),
(3, 'Interviews', 0, '2022-08-31 14:20:38', '2022-08-31 14:20:38', NULL),
(4, 'Video Trailer', 0, '2022-08-31 14:20:38', '2022-08-31 14:20:38', NULL),
(5, 'Knowledge Center', 0, '2022-08-30 19:00:37', '2022-08-30 19:00:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `homepage_banners`
--

CREATE TABLE `homepage_banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `homepage_banners`
--

INSERT INTO `homepage_banners` (`id`, `title`, `sub_title`, `image`, `url`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Film market', 'sub title', '/public/images/home_banners/1660855445_cd237035f011ce35be75.jpg', 'https://google.com', 1, '2022-08-18 15:37:21', '2022-08-18 15:44:05', NULL),
(2, 'Film Incubator', 'sub title', '/public/images/home_banners/1660855506_2b9637715d443ed9b56f.jpg', 'http://google.com', 1, '2022-08-18 15:45:06', '2022-08-18 15:45:06', NULL),
(3, 'Film Festival', 'sub title', '/public/images/home_banners/1660855602_76123959d83c7c1415e0.jpg', 'https://google.com', 1, '2022-08-18 15:46:42', '2022-08-18 15:46:42', NULL),
(4, 'Prime Watch', 'sub title', '/public/images/home_banners/1660855644_ede7506a1704361eeb25.jpg', 'https://google.com', 1, '2022-08-18 15:47:24', '2022-08-18 15:47:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `native_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `native_name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'ab', 'Abkhaz', 'аҧсуа', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(2, 'aa', 'Afar', 'Afaraf', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(3, 'af', 'Afrikaans', 'Afrikaans', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(4, 'ak', 'Akan', 'Akan', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(5, 'sq', 'Albanian', 'Shqip', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(6, 'am', 'Amharic', 'አማርኛ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(7, 'ar', 'Arabic', 'العربية', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(8, 'an', 'Aragonese', 'Aragonés', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(9, 'hy', 'Armenian', 'Հայերեն', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(10, 'as', 'Assamese', 'অসমীয়া', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(11, 'av', 'Avaric', 'авар мацӀ, магӀарул мацӀ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(12, 'ae', 'Avestan', 'avesta', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(13, 'ay', 'Aymara', 'aymar aru', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(14, 'az', 'Azerbaijani', 'azərbaycan dili', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(15, 'bm', 'Bambara', 'bamanankan', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(16, 'ba', 'Bashkir', 'башҡорт теле', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(17, 'eu', 'Basque', 'euskara, euskera', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(18, 'be', 'Belarusian', 'Беларуская', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(19, 'bn', 'Bengali', 'বাংলা', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(20, 'bh', 'Bihari', 'भोजपुरी', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(21, 'bi', 'Bislama', 'Bislama', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(22, 'bs', 'Bosnian', 'bosanski jezik', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(23, 'br', 'Breton', 'brezhoneg', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(24, 'bg', 'Bulgarian', 'български език', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(25, 'my', 'Burmese', 'ဗမာစာ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(26, 'ca', 'Catalan; Valencian', 'Català', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(27, 'ch', 'Chamorro', 'Chamoru', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(28, 'ce', 'Chechen', 'нохчийн мотт', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(29, 'ny', 'Chichewa; Chewa; Nyanja', 'chiCheŵa, chinyanja', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(30, 'zh', 'Chinese', '中文 (Zhōngwén), 汉语, 漢語', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(31, 'cv', 'Chuvash', 'чӑваш чӗлхи', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(32, 'kw', 'Cornish', 'Kernewek', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(33, 'co', 'Corsican', 'corsu, lingua corsa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(34, 'cr', 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(35, 'hr', 'Croatian', 'hrvatski', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(36, 'cs', 'Czech', 'česky, čeština', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(37, 'da', 'Danish', 'dansk', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(38, 'dv', 'Divehi; Dhivehi; Maldivian;', 'ދިވެހި', 0, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(39, 'nl', 'Dutch', 'Nederlands, Vlaams', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(40, 'en', 'English', 'English', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(41, 'eo', 'Esperanto', 'Esperanto', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(42, 'et', 'Estonian', 'eesti, eesti keel', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(43, 'ee', 'Ewe', 'Eʋegbe', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(44, 'fo', 'Faroese', 'føroyskt', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(45, 'fj', 'Fijian', 'vosa Vakaviti', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(46, 'fi', 'Finnish', 'suomi, suomen kieli', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(47, 'fr', 'French', 'français, langue française', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(48, 'ff', 'Fula; Fulah; Pulaar; Pular', 'Fulfulde, Pulaar, Pular', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(49, 'gl', 'Galician', 'Galego', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(50, 'ka', 'Georgian', 'ქართული', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(51, 'de', 'German', 'Deutsch', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(52, 'el', 'Greek, Modern', 'Ελληνικά', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(53, 'gn', 'Guaraní', 'Avañeẽ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(54, 'gu', 'Gujarati', 'ગુજરાતી', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(55, 'ht', 'Haitian; Haitian Creole', 'Kreyòl ayisyen', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(56, 'ha', 'Hausa', 'Hausa, هَوُسَ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(57, 'he', 'Hebrew (modern)', 'עברית', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(58, 'hz', 'Herero', 'Otjiherero', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(59, 'hi', 'Hindi', 'हिन्दी, हिंदी', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(60, 'ho', 'Hiri Motu', 'Hiri Motu', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(61, 'hu', 'Hungarian', 'Magyar', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(62, 'ia', 'Interlingua', 'Interlingua', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(63, 'id', 'Indonesian', 'Bahasa Indonesia', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(64, 'ie', 'Interlingue', 'Originally called Occidental; then Interlingue after WWII', 0, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(65, 'ga', 'Irish', 'Gaeilge', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(66, 'ig', 'Igbo', 'Asụsụ Igbo', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(67, 'ik', 'Inupiaq', 'Iñupiaq, Iñupiatun', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(68, 'io', 'Ido', 'Ido', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(69, 'is', 'Icelandic', 'Íslenska', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(70, 'it', 'Italian', 'Italiano', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(71, 'iu', 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(72, 'ja', 'Japanese', '日本語 (にほんご／にっぽんご)', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(73, 'jv', 'Javanese', 'basa Jawa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(74, 'kl', 'Kalaallisut, Greenlandic', 'kalaallisut, kalaallit oqaasii', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(75, 'kn', 'Kannada', 'ಕನ್ನಡ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(76, 'kr', 'Kanuri', 'Kanuri', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(77, 'ks', 'Kashmiri', 'कश्मीरी, كشميري‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(78, 'kk', 'Kazakh', 'Қазақ тілі', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(79, 'km', 'Khmer', 'ភាសាខ្មែរ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(80, 'ki', 'Kikuyu, Gikuyu', 'Gĩkũyũ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(81, 'rw', 'Kinyarwanda', 'Ikinyarwanda', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(82, 'ky', 'Kirghiz, Kyrgyz', 'кыргыз тили', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(83, 'kv', 'Komi', 'коми кыв', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(84, 'kg', 'Kongo', 'KiKongo', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(85, 'ko', 'Korean', '한국어 (韓國語), 조선말 (朝鮮語)', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(86, 'ku', 'Kurdish', 'Kurdî, كوردی‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(87, 'kj', 'Kwanyama, Kuanyama', 'Kuanyama', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(88, 'la', 'Latin', 'latine, lingua latina', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(89, 'lb', 'Luxembourgish, Letzeburgesch', 'Lëtzebuergesch', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(90, 'lg', 'Luganda', 'Luganda', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(91, 'li', 'Limburgish, Limburgan, Limburger', 'Limburgs', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(92, 'ln', 'Lingala', 'Lingála', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(93, 'lo', 'Lao', 'ພາສາລາວ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(94, 'lt', 'Lithuanian', 'lietuvių kalba', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(95, 'lu', 'Luba-Katanga', '', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(96, 'lv', 'Latvian', 'latviešu valoda', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(97, 'gv', 'Manx', 'Gaelg, Gailck', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(98, 'mk', 'Macedonian', 'македонски јазик', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(99, 'mg', 'Malagasy', 'Malagasy fiteny', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(100, 'ms', 'Malay', 'bahasa Melayu, بهاس ملايو‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(101, 'ml', 'Malayalam', 'മലയാളം', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(102, 'mt', 'Maltese', 'Malti', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(103, 'mi', 'Māori', 'te reo Māori', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(104, 'mr', 'Marathi (Marāṭhī)', 'मराठी', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(105, 'mh', 'Marshallese', 'Kajin M̧ajeļ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(106, 'mn', 'Mongolian', 'монгол', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(107, 'na', 'Nauru', 'Ekakairũ Naoero', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(108, 'nv', 'Navajo, Navaho', 'Diné bizaad, Dinékʼehǰí', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(109, 'nb', 'Norwegian Bokmål', 'Norsk bokmål', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(110, 'nd', 'North Ndebele', 'isiNdebele', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(111, 'ne', 'Nepali', 'नेपाली', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(112, 'ng', 'Ndonga', 'Owambo', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(113, 'nn', 'Norwegian Nynorsk', 'Norsk nynorsk', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(114, 'no', 'Norwegian', 'Norsk', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(115, 'ii', 'Nuosu', 'ꆈꌠ꒿ Nuosuhxop', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(116, 'nr', 'South Ndebele', 'isiNdebele', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(117, 'oc', 'Occitan', 'Occitan', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(118, 'oj', 'Ojibwe, Ojibwa', 'ᐊᓂᔑᓈᐯᒧᐎᓐ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(119, 'cu', 'Old Church Slavonic, Church Slavic, Church Slavonic, Old Bulgarian, Old Slavonic', 'ѩзыкъ словѣньскъ', 0, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(120, 'om', 'Oromo', 'Afaan Oromoo', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(121, 'or', 'Oriya', 'ଓଡ଼ିଆ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(122, 'os', 'Ossetian, Ossetic', 'ирон æвзаг', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(123, 'pa', 'Panjabi, Punjabi', 'ਪੰਜਾਬੀ, پنجابی‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(124, 'pi', 'Pāli', 'पाऴि', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(125, 'fa', 'Persian', 'فارسی', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(126, 'pl', 'Polish', 'polski', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(127, 'ps', 'Pashto, Pushto', 'پښتو', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(128, 'pt', 'Portuguese', 'Português', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(129, 'qu', 'Quechua', 'Runa Simi, Kichwa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(130, 'rm', 'Romansh', 'rumantsch grischun', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(131, 'rn', 'Kirundi', 'kiRundi', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(132, 'ro', 'Romanian, Moldavian, Moldovan', 'română', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(133, 'ru', 'Russian', 'русский язык', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(134, 'sa', 'Sanskrit (Saṁskṛta)', 'संस्कृतम्', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(135, 'sc', 'Sardinian', 'sardu', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(136, 'sd', 'Sindhi', 'सिन्धी, سنڌي، سندھی‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(137, 'se', 'Northern Sami', 'Davvisámegiella', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(138, 'sm', 'Samoan', 'gagana faa Samoa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(139, 'sg', 'Sango', 'yângâ tî sängö', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(140, 'sr', 'Serbian', 'српски језик', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(141, 'gd', 'Scottish Gaelic; Gaelic', 'Gàidhlig', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(142, 'sn', 'Shona', 'chiShona', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(143, 'si', 'Sinhala, Sinhalese', 'සිංහල', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(144, 'sk', 'Slovak', 'slovenčina', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(145, 'sl', 'Slovene', 'slovenščina', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(146, 'so', 'Somali', 'Soomaaliga, af Soomaali', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(147, 'st', 'Southern Sotho', 'Sesotho', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(148, 'es', 'Spanish; Castilian', 'español, castellano', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(149, 'su', 'Sundanese', 'Basa Sunda', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(150, 'sw', 'Swahili', 'Kiswahili', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(151, 'ss', 'Swati', 'SiSwati', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(152, 'sv', 'Swedish', 'svenska', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(153, 'ta', 'Tamil', 'தமிழ்', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(154, 'te', 'Telugu', 'తెలుగు', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(155, 'tg', 'Tajik', 'тоҷикӣ, toğikī, تاجیکی‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(156, 'th', 'Thai', 'ไทย', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(157, 'ti', 'Tigrinya', 'ትግርኛ', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(158, 'bo', 'Tibetan Standard, Tibetan, Central', 'བོད་ཡིག', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(159, 'tk', 'Turkmen', 'Türkmen, Түркмен', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(160, 'tl', 'Tagalog', 'Wikang Tagalog, ᜏᜒᜃᜅ᜔ ᜆᜄᜎᜓᜄ᜔', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(161, 'tn', 'Tswana', 'Setswana', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(162, 'to', 'Tonga (Tonga Islands)', 'faka Tonga', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(163, 'tr', 'Turkish', 'Türkçe', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(164, 'ts', 'Tsonga', 'Xitsonga', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(165, 'tt', 'Tatar', 'татарча, tatarça, تاتارچا‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(166, 'tw', 'Twi', 'Twi', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(167, 'ty', 'Tahitian', 'Reo Tahiti', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(168, 'ug', 'Uighur, Uyghur', 'Uyƣurqə, ئۇيغۇرچە‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(169, 'uk', 'Ukrainian', 'українська', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(170, 'ur', 'Urdu', 'اردو', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(171, 'uz', 'Uzbek', 'zbek, Ўзбек, أۇزبېك‎', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(172, 've', 'Venda', 'Tshivenḓa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(173, 'vi', 'Vietnamese', 'Tiếng Việt', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(174, 'vo', 'Volapük', 'Volapük', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(175, 'wa', 'Walloon', 'Walon', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(176, 'cy', 'Welsh', 'Cymraeg', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(177, 'wo', 'Wolof', 'Wollof', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(178, 'fy', 'Western Frisian', 'Frysk', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(179, 'xh', 'Xhosa', 'isiXhosa', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(180, 'yi', 'Yiddish', 'ייִדיש', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(181, 'yo', 'Yoruba', 'Yorùbá', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL),
(182, 'za', 'Zhuang, Chuang', 'Saɯ cueŋƅ, Saw cuengh', 1, '2022-08-28 23:25:04', '2022-08-28 23:25:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `supports`
--

CREATE TABLE `supports` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `subject` varchar(255) NOT NULL DEFAULT 'Mini Box Office Platform',
  `for_table` varchar(255) NOT NULL DEFAULT 'global',
  `entity_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) UNSIGNED NOT NULL,
  `type` enum('global','festival','filmmarket') NOT NULL DEFAULT 'global',
  `module_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `type`, `module_id`, `content`, `rating`, `name`, `designation`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'global', NULL, 'Flash Film is an award winning creative production company working for various clients and agencies in both New York &amp; LA', 3.5, 'Alan Spider', 'Manager', '2022-09-07 06:35:29', '2022-09-07 07:58:16', NULL),
(2, 'global', NULL, 'Her face has the flawless sheen of Photoshop-adjusted models in cosmetics ads &ndash; an uncanny smoothness that leads us to make our own inferences about her character', 4, 'Jonathan Romney', 'Author of Atom Egoyan (2003)', '2022-09-07 07:28:33', '2022-09-07 07:28:33', NULL),
(3, 'festival', 4, 'Her face has the flawless sheen of Photoshop-adjusted models in cosmetics ads &ndash; an uncanny smoothness that leads us to make our own inferences about her character', 4, 'Jonathan Romney', 'Author of Atom Egoyan (2003)', '2022-09-07 07:28:33', '2022-09-07 07:28:33', NULL),
(4, 'festival', 4, 'Flash Film is an award winning creative production company working for various clients and agencies in both New York &amp; LA', 3.5, 'Alan Spider', 'Manager', '2022-09-07 06:35:29', '2022-09-07 07:58:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `device` enum('web','android','ios','others') NOT NULL DEFAULT 'web',
  `role` enum('user','admin','staff') NOT NULL DEFAULT 'user',
  `is_dev` tinyint(1) NOT NULL DEFAULT 0,
  `module` enum('default','super','festival','market','incubator','filmzine','primewatch','primekids','store','management') NOT NULL DEFAULT 'default',
  `permissions` enum('view','add','edit','delete','all') NOT NULL DEFAULT 'view',
  `email_status` enum('verified','pending','rejected') NOT NULL DEFAULT 'pending',
  `mobile_status` enum('verified','pending','rejected') NOT NULL DEFAULT 'pending',
  `text_status` enum('verified','pending','rejected') NOT NULL DEFAULT 'pending',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '''0=pending/rejected'', ''1=verified''',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile`, `password`, `profile_pic`, `token`, `about`, `profession`, `device`, `role`, `is_dev`, `module`, `permissions`, `email_status`, `mobile_status`, `text_status`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ahtesham', 'Chaudhary', 'ahtesham2000@gmail.com', '9810763314', '$2y$10$33tFVJuUA/dKvl1pXPuvJeTZVCvlgCv.7VqB0OIe4LKDug2CFRe/m', NULL, 'WyIxIiwxNjYyNTQ4NDQ2LDE2NDYwODgzMjRd', NULL, NULL, 'web', 'admin', 1, 'super', 'all', 'verified', 'verified', 'verified', 1, '2022-08-08 05:41:02', '2022-09-07 06:00:46', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `awards`
--
ALTER TABLE `awards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `award_categories`
--
ALTER TABLE `award_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `short_name` (`short_name`);

--
-- Indexes for table `dynamicpagesdatas`
--
ALTER TABLE `dynamicpagesdatas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_categories`
--
ALTER TABLE `events_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_contacts`
--
ALTER TABLE `events_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_contact_submitions`
--
ALTER TABLE `events_contact_submitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_tickets`
--
ALTER TABLE `events_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festivals`
--
ALTER TABLE `festivals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_about`
--
ALTER TABLE `festival_about`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `festival_id` (`festival_id`);

--
-- Indexes for table `festival_awards`
--
ALTER TABLE `festival_awards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_awards_page`
--
ALTER TABLE `festival_awards_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_banners`
--
ALTER TABLE `festival_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_deadlines`
--
ALTER TABLE `festival_deadlines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_delegates`
--
ALTER TABLE `festival_delegates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_delegate_packages`
--
ALTER TABLE `festival_delegate_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_galleries`
--
ALTER TABLE `festival_galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_juries`
--
ALTER TABLE `festival_juries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_jury_galleries`
--
ALTER TABLE `festival_jury_galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_presses`
--
ALTER TABLE `festival_presses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_schedules`
--
ALTER TABLE `festival_schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_sponsorship`
--
ALTER TABLE `festival_sponsorship`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_teams`
--
ALTER TABLE `festival_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_type_of_films`
--
ALTER TABLE `festival_type_of_films`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_venues`
--
ALTER TABLE `festival_venues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_venues_items`
--
ALTER TABLE `festival_venues_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_volunteers`
--
ALTER TABLE `festival_volunteers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `festival_winners`
--
ALTER TABLE `festival_winners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filmzine`
--
ALTER TABLE `filmzine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filmzinetomodules`
--
ALTER TABLE `filmzinetomodules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filmzine_likes`
--
ALTER TABLE `filmzine_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filmzine_topics`
--
ALTER TABLE `filmzine_topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filmzine_types`
--
ALTER TABLE `filmzine_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homepage_banners`
--
ALTER TABLE `homepage_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supports`
--
ALTER TABLE `supports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `awards`
--
ALTER TABLE `awards`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `award_categories`
--
ALTER TABLE `award_categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `dynamicpagesdatas`
--
ALTER TABLE `dynamicpagesdatas`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `events_categories`
--
ALTER TABLE `events_categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events_contacts`
--
ALTER TABLE `events_contacts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events_contact_submitions`
--
ALTER TABLE `events_contact_submitions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events_tickets`
--
ALTER TABLE `events_tickets`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `festivals`
--
ALTER TABLE `festivals`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `festival_about`
--
ALTER TABLE `festival_about`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `festival_awards`
--
ALTER TABLE `festival_awards`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `festival_awards_page`
--
ALTER TABLE `festival_awards_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `festival_banners`
--
ALTER TABLE `festival_banners`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `festival_deadlines`
--
ALTER TABLE `festival_deadlines`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `festival_delegates`
--
ALTER TABLE `festival_delegates`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `festival_delegate_packages`
--
ALTER TABLE `festival_delegate_packages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `festival_galleries`
--
ALTER TABLE `festival_galleries`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `festival_juries`
--
ALTER TABLE `festival_juries`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `festival_jury_galleries`
--
ALTER TABLE `festival_jury_galleries`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `festival_presses`
--
ALTER TABLE `festival_presses`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `festival_schedules`
--
ALTER TABLE `festival_schedules`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `festival_sponsorship`
--
ALTER TABLE `festival_sponsorship`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `festival_teams`
--
ALTER TABLE `festival_teams`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `festival_type_of_films`
--
ALTER TABLE `festival_type_of_films`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `festival_venues`
--
ALTER TABLE `festival_venues`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `festival_venues_items`
--
ALTER TABLE `festival_venues_items`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `festival_volunteers`
--
ALTER TABLE `festival_volunteers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `festival_winners`
--
ALTER TABLE `festival_winners`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `filmzine`
--
ALTER TABLE `filmzine`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `filmzinetomodules`
--
ALTER TABLE `filmzinetomodules`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `filmzine_likes`
--
ALTER TABLE `filmzine_likes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `filmzine_topics`
--
ALTER TABLE `filmzine_topics`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `filmzine_types`
--
ALTER TABLE `filmzine_types`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `homepage_banners`
--
ALTER TABLE `homepage_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;

--
-- AUTO_INCREMENT for table `supports`
--
ALTER TABLE `supports`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
